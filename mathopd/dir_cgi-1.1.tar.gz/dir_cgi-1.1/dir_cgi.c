/*
 *   Copyright 2003, 2004, 2005 Michiel Boland.
 *   All rights reserved.
 *
 *   Redistribution and use in source and binary forms, with or
 *   without modification, are permitted provided that the following
 *   conditions are met:
 *
 *   1. Redistributions of source code must retain the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer.
 *
 *   2. Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 *   3. The name of the author may not be used to endorse or promote
 *      products derived from this software without specific prior
 *      written permission.
 *
 *   THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 *   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *   THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 *   PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR
 *   BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *   ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *   LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 *   IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 *   THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

struct cgi_dir_entry {
	char *name;
	off_t size;
	mode_t mode;
	time_t last_modified;
};


static int cde_compare(const void *a, const void *b)
{
	return strcmp(((struct cgi_dir_entry *) a)->name, ((struct cgi_dir_entry *) b)->name);
}

static void escape_url_print(const char *s)
{
	int c;

	while ((c = *s++) != 0)
		if (!isprint(c))
			printf("%%%02x", c & 0xff); /* ugh */
		else
			switch (c) {
			case '<':
				printf("&lt;");
				break;
			case '&':
				printf("%%26");
				break;
			case '"':
				printf("%%22");
				break;
			case '?':
				printf("%%3f");
				break;
			case '#':
				printf("%%23");
				break;
			case ' ':
				printf("%%20");
				break;
			case '%':
				printf("%%25");
				break;
			default:
				putchar(c);
			}
}

static void escape_html_print(const char *s)
{
	int c;

	while ((c = *s++) != 0)
		switch (c) {
		case '<':
			printf("&lt;");
			break;
		case '&':
			printf("&amp;");
			break;
		case '"':
			printf("&quot;");
			break;
		default:
			putchar(c);
		}
}

static char *iso_date(const time_t t)
{
	static char buf[20];

	strftime(buf, 20, "%Y-%m-%d %T", gmtime(&t));
	return buf;
}

static int sort_and_print(struct cgi_dir_entry *p, size_t n)
{
	int notinroot;
	size_t i;
	const char *script_name;

	if (n)
		qsort(p, n, sizeof *p, cde_compare);
	setvbuf(stdout, 0, _IOFBF, 0);
	printf("Cache-Control: max-age=900\n");
	printf("Content-Type: text/html\n\n");
	script_name = getenv("SCRIPT_NAME");
	printf("<html><head><title>Index");
	if (script_name) {
		notinroot = strcmp(script_name, "/");
		printf(" of %s", script_name);
	} else
		notinroot = 1;
	printf("</title></head>\n");
	printf("<body bgcolor=white text=black link=darkblue vlink=firebrick>\n");
	printf("<H1>Index");
	if (script_name)
		printf(" of %s", script_name);
	printf("</h1>\n");
	printf("<hr noshade size=1>\n");
	printf("<pre><b>%-19s  %12s  %s</b>\n\n", "Last modified", "Size", "Name");

	for (i = 0; i < n; i++) {
		if (S_ISDIR(p[i].mode)) {
			if (!notinroot && !strcmp(p[i].name, "..")) 
				continue;
			printf("%19s %19s  ", iso_date(p[i].last_modified), "&lt;DIR&gt;");			
			printf("<a href=\"");
			escape_url_print(p[i].name);
			printf("/\">");
			escape_html_print(p[i].name);
			printf("/</a>\n");
		}
	}

	for (i = 0; i < n; i++) {
		if (S_ISREG(p[i].mode)) {
			printf("%19s ", iso_date(p[i].last_modified));
			printf("%10.2lf kB  ", p[i].size/1024.0);
			printf("<a href=\"");
			escape_url_print(p[i].name);
			printf("\">");
			escape_html_print(p[i].name);
			printf("</a>\n");
		}
	}

	printf("</pre><hr noshade size=1>\n");
	printf("<small>%s</small>", getenv("SERVER_SOFTWARE"));
	printf("</body></html>\n");
	return 0;
}

static int hide_name(const char *s)
{
	if (getenv("SHOW_DOTFILES"))
		return s[0] == 0 || (s[0] == '.' && !s[1] ) || access(s, R_OK);
	return s[0] == 0 || (s[0] == '.' && s[1] != '.') || access(s, R_OK);
}

static int do_dir(const char *dirname)
{
	struct cgi_dir_entry *p, *q;
	size_t n;
	int rv;
	struct stat finfo;
	DIR *d;
	struct dirent *e;

	p = 0;
	n = 0;
	rv = 0;
	d = opendir(dirname);
	if (d == 0) {
		perror("opendir");
		return 1;
	}
	while ((e = readdir(d)) != 0) {
		if (hide_name(e->d_name))
			continue;
		if (lstat(e->d_name, &finfo) == -1) {
			perror("lstat");
			rv = 1;
			break;
		}
		q = realloc(p, (n + 1) * sizeof *p);
		if (q == 0) {
			rv = 1;
			break;
		}
		p = q;
		p[n].name = strdup(e->d_name);
		if (p[n].name == 0) {
			rv = 1;
			break;
		}
		p[n].size = finfo.st_size;
		p[n].mode = finfo.st_mode;
		p[n].last_modified = finfo.st_mtime;
		++n;
	}
	closedir(d);
	if (rv == 0)
		rv = sort_and_print(p, n);
	while (n) {
		--n;
		free(p[n].name);
	}
	if (p)
		free(p);
	return rv;
}

int main(void)
{
	return do_dir(".");
}

